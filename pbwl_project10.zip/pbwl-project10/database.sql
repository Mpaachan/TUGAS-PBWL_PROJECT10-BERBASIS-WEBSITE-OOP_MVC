CREATE TABLE tb_desain (
 desain_id TINYINT(3) NOT NULL AUTO_INCREMENT,
	desain_nama VARCHAR(50) NOT NULL,
	desain_harga INT(12) NOT NULL,
	created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	updated_at DATETIME DEFAULT NULL,
	PRIMARY KEY(desain_id)
);
CREATE TABLE tb_pelanggan (
	pel_id TINYINT(3) NOT NULL AUTO_INCREMENT,
	desain_id TINYINT(3) NOT NULL,
	user_full_name VARCHAR(100) DEFAULT NULL,
	user_alamat TEXT NOT NULL,
	user_hp CHAR(12) NOT NULL,
	user_id TINYINT(3) NOT NULL,
	pel_aktif enum("Y",'N'),
	created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	updated_at DATETIME DEFAULT NULL,
	PRIMARY KEY(pel_id),
	UNIQUE KEY(desain_id),
	UNIQUE KEY(user_id)
);
CREATE TABLE tb_users (
	user_id TINYINT(3) NOT NULL AUTO_INCREMENT,
	user_email VARCHAR(50) NOT NULL,
	user_password VARCHAR(100) NOT NULL,
	user_full_name VARCHAR(100) DEFAULT NULL,
	user_alamat TEXT NOT NULL,
	user_hp CHAR(12) NOT NULL,
	user_role TINYINT(2) NOT NULL,
	user_aktif TINYINT(2) NOT NULL,
	created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
	updated_at DATETIME DEFAULT NULL,
	PRIMARY KEY(user_id),
	UNIQUE KEY(user_email)
);
INSERT INTO
	tb_users
VALUES
	(
		1,
		'admin@gmail.com',
		'*4ACFE3202A5FF5CF467898FC58AAB1D615029441',
		'A DESAIN',
		'Medan',
		'083180492298',
		'03',
		'06',
		'2023-11-29 04:58:43',
		NULL
	);