<?php

namespace App\Models;

use App\Core\Model;

class desain extends Model
{

     public function show()
     {
          $query = "SELECT * FROM tb_desain";
          $stmt = $this->db->prepare($query);
          $stmt->execute();

          return $this->selects($stmt);
     }

     public function save()
     {
          $desain_nama = $_POST['desain_nama'];
          $desain_harga = $_POST['desain_harga'];

          $sql = "INSERT INTO tb_desain SET desain_nama=:desain_nama, desain_harga=:desain_harga";
          $stmt = $this->db->prepare($sql);

          $stmt->bindParam(":desain_nama", $desain_nama);
          $stmt->bindParam(":desain_harga", $desain_harga);

          $stmt->execute();
     }

     public function edit($id)
     {
          $query = "SELECT * FROM tb_desain WHERE desain_id=:desain_id";
          $stmt = $this->db->prepare($query);

          $stmt->bindParam(":desain_id", $id);
          $stmt->execute();

          return $this->select($stmt);
     }

     public function update()
     {
          $desain_nama = $_POST['desain_nama'];
          $desain_harga = $_POST['desain_harga'];
          $id = $_POST['id'];

          $sql = "UPDATE tb_desain
          SET desain_nama=:desain_nama, desain_harga=:desain_harga WHERE desain_id=:desain_id";

          $stmt = $this->db->prepare($sql);

          $stmt->bindParam(":desain_nama", $desain_nama);
          $stmt->bindParam(":desain_harga", $desain_harga);
          $stmt->bindParam(":desain_id", $id);

          $stmt->execute();
     }
}
