<h2>Desain</h2>

<a href="<?php echo URL; ?>/desain/input" class="btn">Input Desain</a>

<table id="dtb">
<thead>
      <tr>
            <th>NO</th>
            <th>ID DESAIN</th>
            <th>NAMA DESAIN</th>
            <th>HARGA</th>
            <th>EDIT</th>
      </tr> 
    </thead>
    <tbody>
      <?php $no = 1;
      foreach ($data['rows'] as $row) { ?>
            <tr>
                  <td><?php echo $no; ?></td>
                  <td><?php echo $row['desain_id']; ?></td>
                  <td><?php echo $row['desain_nama']; ?></td>
                  <td><?php echo $row['desain_harga']; ?></td>
                  <td><a href="<?php echo URL; ?>/desain/edit/<?php echo $row['desain_id']; ?>" class="btn">Edit</a></td>
            </tr>
      <?php $no++;
      } ?>
      </tbody>

</table>