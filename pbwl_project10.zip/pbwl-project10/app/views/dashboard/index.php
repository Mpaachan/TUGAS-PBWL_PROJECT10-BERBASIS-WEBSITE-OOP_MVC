<h2>A DESAIN BY SHILA</h2>

<div class="info">MAU DESAIN? <b>disini aja</b></div>
<div class="info">Jasa Desain Grafis yang bisa kamu pilih sesuai selera, temukan style kamu disini!
            <p>Disini Kami Akan Membantu Kamu dalam membuat Desain yang Terbaik</p>
</div>
<div class="info"><b>Mari Pesan Desain!</b></div>
<div class="info"><b>Contoh Desain:</b>
    <p>- Poster</p>
    <p>- Flyer</p>
    <p>- ID Card</p>
    <p>- Logo</p>
    <p>- Banner</p>
</div>